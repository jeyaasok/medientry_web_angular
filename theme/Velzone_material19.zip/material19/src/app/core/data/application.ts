// Application
const application = [
    // {
    //     id: "001",
    //     img: "assets/images/companies/img-4.png",
    //     name: "Syntyce Solutions",
    //     designation: "Web Designer",
    //     date: "30 Sep, 2022",
    //     contacts: "785-685-4616",
    //     type: "Full Time",
    //     status: "Rejected"
    // },
    {
        id: 2,
        img: "assets/images/brands/slack.png",
        name: "Plunkett Infotech",
        designation: "Product Designer",
        date: "26 Sep, 2022",
        contacts: "734-544-2407",
        type: "Full Time",
        status: "New"
    }, {
        id: 3,
        img: "assets/images/companies/img-4.png",
        name: "Martin's",
        designation: "Business Associate",
        date: "26 Sep, 2022",
        contacts: "303-606-1985",
        type: "Part Time",
        status: "New"
    }, {
        id: 4,
        img: "assets/images/companies/img-3.png",
        name: "Meta4Systems",
        designation: "Magento Developer",
        date: "27 Sep, 2022",
        contacts: "610-440-0592",
        type: "Part Time",
        status: "Rejected"
    }, {
        id: 5,
        img: "assets/images/companies/img-4.png",
        name: "Grey Fade",
        designation: "Marketing Director",
        date: "28 Sep, 2022",
        contacts: "907-452-3702",
        type: "Full Time",
        status: "Pending"
    }, {
        id: 6,
        img: "assets/images/brands/mail_chimp.png",
        name: "Syntyce Solutions",
        designation: "Project Manager",
        date: "28 Sep, 2022",
        contacts: "803-740-3309",
        type: "Part Time",
        status: "Approved"
    }, {
        id: 7,
        img: "assets/images/brands/dropbox.png",
        name: "Micro Design",
        designation: "HTML Developer",
        date: "29 Sep, 2022",
        contacts: "563-940-8926",
        type: "Part Time",
        status: "New"
    }, {
        id: 8,
        img: "assets/images/companies/img-6.png",
        name: "Android Galaxy",
        designation: "Product Sales Specialist",
        date: "29 Sep, 2022",
        contacts: "352-403-5870",
        type: "Full Time",
        status: "Pending"
    }, {
        id: 9,
        img: "assets/images/companies/img-1.png",
        name: "Digitech Galaxy",
        designation: "Magento Developer",
        date: "29 Sep, 2022",
        contacts: "517-745-4446",
        type: "Part Time",
        status: "New"
    }, {
        id: 10,
        img: "assets/images/brands/bitbucket.png",
        name: "iTest Factory",
        designation: "Business Associate",
        date: "30 Sep, 2022",
        contacts: "814-434-0128",
        type: "Part Time",
        status: "Approved"
    }, {
        id: 11,
        img: "assets/images/brands/dribbble.png",
        name: "Nesta Technologies",
        designation: "UI/UX Designer",
        date: "01 Sep, 2022",
        contacts: "304-338-0822",
        type: "Part Time",
        status: "Pending"
    }, {
        id: 12,
        img: "assets/images/companies/img-4.png",
        name: "Digitech Galaxy",
        designation: "Product Designer",
        date: "02 Sep, 2022",
        contacts: "320-336-1796",
        type: "Full Time",
        status: "New"
    }, {
        id: 12,
        img: "assets/images/brands/slack.png",
        name: "Syntyce Solutions",
        designation: "Web Designer",
        date: "02 Sep, 2022",
        contacts: "785-685-4616",
        type: "Full Time",
        status: "Rejected"
    }
]

export { application }