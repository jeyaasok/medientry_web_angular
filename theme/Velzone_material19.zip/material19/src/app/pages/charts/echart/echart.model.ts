export interface ChartType {
    xAxis?: any;
    yAxis?: any;
    series?: any;
    color?: any;
    tooltip?: any;
    grid?: any;
    legend?: any;
    animationEasing?: any;
    dataZoom?: any;
    toolbox?: any;
}
