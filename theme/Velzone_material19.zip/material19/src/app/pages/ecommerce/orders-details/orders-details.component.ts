import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-orders-details',
    templateUrl: './orders-details.component.html',
    styleUrls: ['./orders-details.component.scss'],
    standalone: false
})

/**
 * OrdersDetails Component
 */
export class OrdersDetailsComponent implements OnInit {

  // bread crumb items
  breadCrumbItems!: Array<{}>;

  constructor() {

   }

  ngOnInit(): void {
    /**
    * BreadCrumb
    */
     this.breadCrumbItems = [
      { label: 'Ecommerce' },
      { label: 'Order Details', active: true }
    ];

  }

}
